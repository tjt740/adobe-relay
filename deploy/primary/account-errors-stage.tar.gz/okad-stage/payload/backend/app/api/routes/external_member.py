from datetime import datetime, timezone
from threading import Lock

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query, Response, status
from sqlalchemy.orm import Session

from app.api.deps import capture_job_request, get_current_user
from app.crud import external_member as crud
from app.db.session import get_db
from app.models.user import User
from app.schemas.adobe_account import JobStatusOut
from app.schemas.common import BatchIds, DEFAULT_PAGE_SIZE, MAX_PAGE_SIZE, MessageResult, Page
from app.schemas.external_member import ExternalBatchProfilePreferenceUpdate, ExternalImportRequest, ExternalLoginFilter, ExternalMemberOut, ExternalNoteUpdate, ExternalProfilePreferenceUpdate
from app.services import external_login, external_sub2, external_sub2_stock, sub2_account_health
from app.services.job_manager import JOBS
from app.services.email_export import XLSX_MEDIA_TYPE, emails_xlsx
from app.schemas.external_member import CreditsField, CurrentProfileKind, SupplyMailConfigUpdate, ExternalOtpModeUpdate, ExternalOtpSubmit
from app.services import supply_mail, manual_otp
from app.crud.setting import _set

router = APIRouter(
    prefix="/external",
    tags=["外部子号"],
    dependencies=[Depends(capture_job_request)],
)
_login_lock = Lock()


@router.get("/mail/config", summary="获取 supply.ink 取信配置状态")
def mail_config(db: Session = Depends(get_db)) -> dict:
    return {"configured": bool(supply_mail.get_token(db)), "api_base": supply_mail.API_BASE}


@router.put("/mail/config", summary="保存 supply.ink 取信 Token")
def save_mail_config(payload: SupplyMailConfigUpdate, db: Session = Depends(get_db)) -> dict:
    import re
    token = re.sub(r"^Bearer\s+", "", (payload.token or "").strip(), flags=re.I)
    if token and not re.fullmatch(r"[A-Za-z0-9._\-]+", token):
        raise HTTPException(status_code=400, detail="Token 格式无效，请粘贴 Token 裸串")
    if payload.clear_token or token:
        _set(db, supply_mail.TOKEN_KEY, "" if payload.clear_token else token)
        db.commit()
    return mail_config(db)


@router.post("/mail/test", summary="测试 supply.ink 邮件连接")
def test_mail(db: Session = Depends(get_db)) -> dict:
    mailbox = supply_mail.SupplyMailbox(supply_mail.get_token(db))
    try:
        return mailbox.test()
    except supply_mail.SupplyMailError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from None
    finally:
        mailbox.close()


@router.get("/members/{member_id}/mail", summary="查看外部子号最近五封 supply.ink 邮件")
def member_mail(member_id: int, db: Session = Depends(get_db)) -> dict:
    member = crud.get(db, member_id)
    if not member:
        raise HTTPException(status_code=404, detail="账号不存在，请刷新后重试")
    mailbox = supply_mail.SupplyMailbox(supply_mail.get_token(db))
    try:
        return {"email": member.email, "messages": mailbox.messages(member.email)}
    except supply_mail.SupplyMailError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from None
    finally:
        mailbox.close()


def _to_out(m, latest_job=None, sub2_target="") -> ExternalMemberOut:
    from app.services.okad_account_metadata import uses_supply_mail
    return ExternalMemberOut(
        id=m.id, email=m.email, note=m.note,
        credits_available=m.credits_available, credits_total=m.credits_total,
        credits_error=m.credits_error or "",
        account_profile=m.account_profile,
        profile_preference=m.profile_preference,
        login_status=m.login_status, subscription_ok=m.subscription_ok,
        first_login_done=m.first_login_done, has_cookie=bool(m.cookie),
        has_adobe_password=bool((m.adobe_password or "").strip()),
        force_code_login=bool(m.force_code_login),
        uses_supply_mail=uses_supply_mail(m),
        otp_mode=m.otp_mode,
        otp_challenge=manual_otp.BROKER.status(m.id),
        last_login_at=m.last_login_at, message=m.message, created_at=m.created_at,
        operator=m.operator or "", latest_job=latest_job,
        **external_sub2.summary(m, sub2_target),
    )


def _sequential_login(members):
    return any(m.force_code_login and m.otp_mode == "auto" for m in members)


def _start_login(members, db, operator):
    cfg = external_sub2.config(db)
    for member in members:
        member.operator = operator
    db.commit()
    meta = {"member_ids": [m.id for m in members], "target": len(members), "operator": operator,
            "batch_size": external_login.LOGIN_BATCH_SIZE, "push_to_sub2": True,
            "sub2_target": external_sub2.destination(cfg),
            "member_emails": {str(m.id): m.email for m in members},
            "member_profile_preferences": {str(m.id): m.profile_preference for m in members},
            "member_code_login": {str(m.id): bool(m.force_code_login) for m in members},
            "member_otp_modes": {str(m.id): m.otp_mode for m in members}}
    if _sequential_login(members):
        meta["sequential_login"] = True
    return JOBS.start("external_login", external_login.batch_login_worker, meta=meta)


def _active_jobs(ids):
    return {mid: jobs[0] for mid, jobs in JOBS.external_member_jobs(ids).items()
            if jobs[0]["status"] in {"running", "pausing", "paused", "cancelling"}}


@router.patch("/members/{member_id}/otp-mode", summary="设置验证码自动获取或手动输入")
def update_otp_mode(member_id: int, payload: ExternalOtpModeUpdate,
                    db: Session = Depends(get_db)) -> dict:
    with _login_lock:
        member = crud.get(db, member_id)
        if not member:
            raise HTTPException(status_code=404, detail="账号不存在，请刷新后重试")
        if _active_jobs([member_id]) or manual_otp.BROKER.status(member_id):
            raise HTTPException(status_code=409, detail="账号正在登录，请结束本次任务后切换取码方式")
        member.otp_mode = payload.otp_mode
        db.commit()
    return {"otp_mode": member.otp_mode, "message": "取码方式已保存，下次登录生效"}


@router.get("/members/{member_id}/otp", summary="查询正在等待的手动验证码请求")
def otp_status(member_id: int, response: Response, db: Session = Depends(get_db)) -> dict:
    if not crud.get(db, member_id):
        raise HTTPException(status_code=404, detail="账号不存在，请刷新后重试")
    response.headers["Cache-Control"] = "no-store"
    return {"challenge": manual_otp.BROKER.status(member_id)}


@router.post("/members/{member_id}/otp", summary="提交本次登录的手动验证码")
def submit_otp(member_id: int, payload: ExternalOtpSubmit,
               db: Session = Depends(get_db)) -> dict:
    if not crud.get(db, member_id):
        raise HTTPException(status_code=404, detail="账号不存在，请刷新后重试")
    try:
        manual_otp.BROKER.submit(member_id, payload.request_id, payload.code)
    except manual_otp.ManualOtpError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from None
    return {"message": "验证码已提交，正在继续登录"}


def _member_filters(db, *, in_stock=None, sub2_health=None, imported_from=None, imported_before=None,
                    credits_min=None, credits_max=None):
    # created_at is stored as UTC without a timezone; accept browser-local
    # date boundaries with their offset and compare them in UTC.
    def utc(value):
        if value is not None and value.tzinfo is not None:
            return value.astimezone(timezone.utc).replace(tzinfo=None)
        return value

    imported_from, imported_before = utc(imported_from), utc(imported_before)
    if imported_from is not None and imported_before is not None and imported_from >= imported_before:
        raise HTTPException(status_code=422, detail="导入时间的结束日期不能早于开始日期")
    if credits_min is not None and credits_max is not None and credits_min > credits_max:
        raise HTTPException(status_code=422, detail="积分最大值不能小于最小值")
    ids = None
    if in_stock is not None or sub2_health is not None:
        stock = external_sub2_stock.membership(db)
        if not stock.get("ok"):
            raise HTTPException(status_code=503, detail=stock.get("message") or "Sub2 库存暂不可用，请稍后重试")
        ids = [int(mid) for mid, item in stock["items"].items()
               if (in_stock is None or item.get("in_stock") is in_stock)
               and (sub2_health is None or (item.get("in_stock") is True
                    and sub2_account_health.matches(item.get("account_health"), sub2_health)))]
    return dict(ids=ids, imported_from=imported_from, imported_before=imported_before,
                credits_min=credits_min, credits_max=credits_max)


@router.get("/members", response_model=Page[ExternalMemberOut], summary="外部子号分页查询")
def list_members(
    page: int = Query(1, ge=1), size: int = Query(DEFAULT_PAGE_SIZE, ge=1, le=MAX_PAGE_SIZE),
    login_status: str | None = None, subscription_ok: bool | None = None,
    keyword: str = "", db: Session = Depends(get_db),
    in_stock: bool | None = None, imported_from: datetime | None = None,
    imported_before: datetime | None = None,
    sub2_health: str | None = Query(None, pattern=sub2_account_health.FILTER_PATTERN),
    credits_field: CreditsField = "available",
    credits_min: float | None = Query(default=None, ge=0, allow_inf_nan=False),
    credits_max: float | None = Query(default=None, ge=0, allow_inf_nan=False),
    current_profile: CurrentProfileKind | None = None, is_company: bool | None = None,
) -> Page[ExternalMemberOut]:
    items, total = crud.list_members(
        db, page=page, size=size, login_status=login_status,
        subscription_ok=subscription_ok, keyword=keyword,
        credits_field=credits_field, current_profile=current_profile, is_company=is_company,
        **_member_filters(db, in_stock=in_stock, sub2_health=sub2_health, imported_from=imported_from, imported_before=imported_before,
                          credits_min=credits_min, credits_max=credits_max),
    )
    jobs = JOBS.external_member_jobs([m.id for m in items])
    target = external_sub2.destination(external_sub2.config(db))
    return Page(items=[_to_out(m, (jobs.get(m.id) or [None])[0], target) for m in items], total=total, page=page, size=size)


@router.get("/members/sub2-stock", summary="按邮箱核对外部子号在 Sub2 的实时库存")
def sub2_stock(refresh: bool = False, db: Session = Depends(get_db)) -> dict:
    return external_sub2_stock.membership(db, refresh=refresh)


@router.patch("/members/{member_id}/note", summary="保存外部子号备注")
def update_note(member_id: int, payload: ExternalNoteUpdate,
                db: Session = Depends(get_db)) -> dict:
    member = crud.get(db, member_id)
    if not member:
        raise HTTPException(status_code=404, detail="账号不存在，请刷新后重试")
    member.note = payload.note.strip()
    db.commit()
    return {"note": member.note, "message": "备注已保存"}


@router.get("/members/{member_id}/sub2-capacity", summary="只读确认账号是否因 Sub2 节点容量不足而等待")
def sub2_capacity(member_id: int, response: Response, db: Session = Depends(get_db)) -> dict:
    response.headers['Cache-Control'] = 'no-store'
    member = crud.get(db, member_id)
    if not member:
        raise HTTPException(status_code=404, detail="账号不存在，请刷新后重试")
    return external_sub2_stock.capacity_detail(db, member)


def _save_login_profiles(ids, preference, db) -> dict:
    with _login_lock:
        ids = list(dict.fromkeys(ids))
        members = crud.get_many(db, ids)
        if len(members) != len(ids):
            raise HTTPException(status_code=404, detail="所选账号已不存在，请刷新后重试")
        if _active_jobs(ids):
            raise HTTPException(status_code=409, detail="账号登录任务尚未结束，请完成或终止后修改登录配置")
        for member in members:
            member.profile_preference = preference
        db.commit()
    return {"profile_preference": preference, "updated": len(members),
            "message": f"已保存 {len(members)} 个账号的登录配置，下次登录生效"}


@router.patch("/members/login-profile", summary="保存选中账号下次登录使用的配置")
def update_login_profiles(payload: ExternalBatchProfilePreferenceUpdate,
                          db: Session = Depends(get_db)) -> dict:
    return _save_login_profiles(payload.ids, payload.profile_preference, db)


@router.patch("/members/{member_id}/login-profile", summary="保存账号下次登录使用的配置")
def update_login_profile(member_id: int, payload: ExternalProfilePreferenceUpdate,
                         db: Session = Depends(get_db)) -> dict:
    return _save_login_profiles([member_id], payload.profile_preference, db)


@router.post("/members/push-sub2", summary="推送选中外部子号并开启重登后 Cookie 同步")
def push_sub2(payload: BatchIds, background: BackgroundTasks, db: Session = Depends(get_db)) -> dict:
    if not payload.ids:
        raise HTTPException(status_code=400, detail="请先勾选账号")
    try:
        target, queued, skipped = external_sub2.prepare(db, payload.ids)
    except external_sub2.SyncError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from None
    background.add_task(external_sub2.submit, queued, target)
    return {"queued": len(queued), "skipped": len(skipped),
            "message": f"已提交 {len(queued)} 个账号同步，跳过 {len(skipped)} 个未登录成功或无 Cookie 的账号"}


@router.post("/members/relink-sub2", summary="手动重新关联 Sub2，缺失账号按邮箱去重后重建")
def relink_sub2(payload: BatchIds, background: BackgroundTasks, db: Session = Depends(get_db),
                user: User = Depends(get_current_user)) -> dict:
    if not payload.ids:
        raise HTTPException(status_code=400, detail="请先勾选账号")
    try:
        target, queued, skipped = external_sub2.prepare(db, payload.ids, relink=True, operator=user.username)
    except external_sub2.SyncError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from None
    background.add_task(external_sub2.submit, queued, target)
    return {"queued": len(queued), "skipped": len(skipped),
            "message": f"已提交 {len(queued)} 个账号重新关联，跳过 {len(skipped)} 个未就绪或正在同步的账号"}


@router.post("/members/import", summary="批量导入外部子号(并自动开批量登录任务)")
def import_members(payload: ExternalImportRequest, db: Session = Depends(get_db),
                   user: User = Depends(get_current_user)) -> dict:
    result = crud.import_lines(db, payload.content, on_duplicate=payload.on_duplicate,
                               operator=user.username, profile_preference=payload.profile_preference,
                               otp_mode=payload.otp_mode)
    ids = result.pop("ids", [])
    # 导入成功后自动开一个批量登录任务(任务列表可见、可看日志)
    if ids:
        with _login_lock:
            active = _active_jobs(ids)
            pending = [mid for mid in ids if mid not in active]
            job_ids = list(dict.fromkeys(j["id"] for j in active.values()))
            if pending:
                members = crud.get_many(db, pending)
                result["sequential_login"] = _sequential_login(members)
                job = _start_login(members, db, user.username)
                job_ids.insert(0, job.id)
            result["job_id"] = job_ids[0]
            result["job_ids"] = job_ids
    return result


@router.post("/members/batch-login", response_model=JobStatusOut, summary="批量登录刷新cookie")
def batch_login(payload: BatchIds, db: Session = Depends(get_db),
                user: User = Depends(get_current_user)) -> JobStatusOut:
    members = crud.get_many(db, payload.ids)
    if not members:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="请先选择账号")
    with _login_lock:
        active = _active_jobs([m.id for m in members])
        job_ids = set(j["id"] for j in active.values())
        if len(active) == len(members) and len(job_ids) == 1:
            return JobStatusOut(**JOBS.get(next(iter(job_ids))).to_dict())
        if active:
            raise HTTPException(status_code=409, detail="所选账号已有登录任务运行中,请等待完成后再重试")
        job = _start_login(members, db, user.username)
    return JobStatusOut(**job.to_dict())


@router.post("/members/batch-login-filter", summary="一键重登当前筛选的全部外部子号")
def batch_login_filter(payload: ExternalLoginFilter, db: Session = Depends(get_db),
                       user: User = Depends(get_current_user)) -> dict:
    filters = payload.model_dump()
    filters.update(_member_filters(db, in_stock=filters.pop("in_stock"),
                                   sub2_health=filters.pop("sub2_health"),
                                   imported_from=filters.pop("imported_from"),
                                   imported_before=filters.pop("imported_before"),
                                   credits_min=filters.pop("credits_min"),
                                   credits_max=filters.pop("credits_max")))
    with _login_lock:
        members, total = crud.list_members(db, size=None, **filters)
        active = _active_jobs([m.id for m in members]) if members else {}
        pending = [m for m in members if m.id not in active]
        job = _start_login(pending, db, user.username) if pending else None
    if job:
        message = f"已提交 {len(pending)} 个账号，每批最多 {external_login.LOGIN_BATCH_SIZE} 个，登录成功后自动推送 Sub2；跳过 {len(active)} 个任务未结束的账号"
    else:
        message = "当前范围暂无外部子号" if not total else f"当前范围的 {len(active)} 个账号任务未结束，无需重复提交"
    return {"job": JobStatusOut(**job.to_dict()) if job else None,
            "queued": len(pending), "skipped": len(active), "total": total, "message": message}


@router.get("/members/{member_id}/jobs", response_model=list[JobStatusOut], summary="外部子号任务历史")
def member_jobs(member_id: int, limit: int = Query(default=200, ge=1, le=MAX_PAGE_SIZE),
                db: Session = Depends(get_db)) -> list[JobStatusOut]:
    if not crud.get(db, member_id):
        raise HTTPException(status_code=404, detail="条目不存在")
    return [JobStatusOut(**j) for j in JOBS.external_member_jobs([member_id], limit=limit).get(member_id, [])]


@router.post("/members/{member_id}/login", summary="单号重登")
def login_one(member_id: int, db: Session = Depends(get_db)) -> dict:
    m = crud.get(db, member_id)
    if not m:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="条目不存在")
    # 把重登过程写进「日志管理」,失败时能看到具体到哪一步、为什么
    return external_login.login_and_store(
        member_id, log=external_login.log_login
    )


@router.get("/members/export", summary="导出 cookie([{cookie}])")
def export_members(
    login_status: str | None = None, subscription_ok: bool | None = None,
    keyword: str = "",
    db: Session = Depends(get_db),
    in_stock: bool | None = None, imported_from: datetime | None = None,
    imported_before: datetime | None = None,
    sub2_health: str | None = Query(None, pattern=sub2_account_health.FILTER_PATTERN),
    credits_field: CreditsField = "available",
    credits_min: float | None = Query(default=None, ge=0, allow_inf_nan=False),
    credits_max: float | None = Query(default=None, ge=0, allow_inf_nan=False),
    current_profile: CurrentProfileKind | None = None, is_company: bool | None = None,
) -> list[dict]:
    return crud.export_cookies(db, login_status=login_status, subscription_ok=subscription_ok, keyword=keyword,
                               credits_field=credits_field, current_profile=current_profile, is_company=is_company,
                               **_member_filters(db, in_stock=in_stock, sub2_health=sub2_health, imported_from=imported_from,
                                                 imported_before=imported_before,
                                                 credits_min=credits_min, credits_max=credits_max))


@router.post("/members/export", summary="导出选中账号的 Cookie")
def export_selected_members(payload: BatchIds, db: Session = Depends(get_db)) -> list[dict]:
    return crud.export_cookies(db, ids=payload.ids)


@router.post("/members/export-emails", summary="导出选中外部子号邮箱为 Excel")
def export_selected_emails(payload: BatchIds, db: Session = Depends(get_db)) -> Response:
    ids = list(dict.fromkeys(payload.ids))
    if not ids:
        raise HTTPException(status_code=400, detail="请先勾选要导出的账号")
    members = crud.get_many(db, ids)
    if len(members) != len(ids):
        raise HTTPException(status_code=404, detail="所选账号已不存在，请刷新后重新勾选导出")
    return Response(
        content=emails_xlsx([member.email for member in members]),
        media_type=XLSX_MEDIA_TYPE,
        headers={"Content-Disposition": 'attachment; filename="external-emails.xlsx"',
                 "Cache-Control": "no-store"},
    )


@router.delete("/members/batch-delete", response_model=MessageResult, summary="批量删除")
def batch_delete(payload: BatchIds, db: Session = Depends(get_db)) -> MessageResult:
    n = crud.delete_many(db, payload.ids)
    return MessageResult(message=f"已删除 {n} 个")
